import sqlite3
from flask import Flask, render_template, redirect, url_for, flash
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import DataRequired, Length
from flask_bcrypt import Bcrypt, check_password_hash

app = Flask(__name__)
app.config['SECRET_KEY'] = '319225974'
app.config['DATABASE'] = 'usuarios.db'
bcrypt = Bcrypt(app)
 
from functools import wraps
from flask import session, request, redirect, url_for

def require_login(view):
    @wraps(view)
    def wrapped_view(**kwargs):
        if 'user_id' not in session:
            flash('Debes iniciar sesión para acceder a esta página.', 'danger')
            return redirect(url_for('inicio_sesion'))
        return view(**kwargs)
    return wrapped_view

@app.route('/inicio-sesion', methods=['GET', 'POST'])
def inicio_sesion():
    form = LoginForm()

    if form.validate_on_submit():
        username = form.username.data
        password = form.password.data

        db = get_db()
        cursor = db.cursor()

        # Verifica las credenciales del usuario
        cursor.execute("SELECT * FROM usuario WHERE username = ?", (username,))
        user = cursor.fetchone()

        if user and check_password_hash(user['password'], password):
            flash(f'¡Inicio de sesión exitoso para {username}!', 'success')

            # Establece la información del usuario en la sesión
            session['user_id'] = user['id']

            return redirect(url_for('index'))
        else:
            flash('Información incorrecta. Inténtalo de nuevo.', 'danger')

    return render_template('inicio_sesion.html', form=form)

from flask import g

@app.route('/')
@require_login
def index():
    return render_template('index.html')

@app.route('/articulos')
def articulos():
    return render_template('articulos.html')

@app.route('/lugares')
def lugares():
    return render_template('lugares.html')

@app.route('/objetos')
def objetos():
    return render_template('objetos.html')

@app.route('/pronombres')
def pronombres():
    return render_template('pronombres.html')

@app.route('/vocabulario')
def vocabulario():
    db = get_db()
    cursor = db.cursor()
    cursor.execute("SELECT * FROM vocabulario")
    vocabulario = cursor.fetchall()

    return render_template('vocabulario.html', vocabulario=vocabulario)

@app.route('/agregar_palabra', methods=['POST'])
def agregar_palabra():
    palabra = request.form['palabra']
    significado = request.form['significado']

    db = get_db()
    cursor = db.cursor()
    cursor.execute("INSERT INTO vocabulario (palabra, significado) VALUES (?, ?)", (palabra, significado))
    db.commit()

    flash(f'Palabra "{palabra}" agregada al vocabulario.', 'success')
    return redirect(url_for('pagina_vocabulario'))

@app.cli.command('init-db')
def init_db_command():
    """Inicializa la base de datos."""
    init_db()
    print('Base de datos inicializada.')

class RegistrationForm(FlaskForm):
    username = StringField('Nombre de Usuario', validators=[DataRequired(), Length(min=4, max=20)])
    password = PasswordField('Contraseña', validators=[DataRequired()])
    submit = SubmitField('Registrarse')

class LoginForm(FlaskForm):
    username = StringField('Nombre de Usuario', validators=[DataRequired()])
    password = PasswordField('Contraseña', validators=[DataRequired()])
    submit = SubmitField('Iniciar Sesión')

def init_db():
    with app.app_context():
        db = get_db()
        schema_path = app.root_path + '/schema.sql'
        with app.open_resource(schema_path, mode='r') as f:
            db.cursor().executescript(f.read())
        db.commit()

def get_db():
    if 'db' not in g:
        g.db = sqlite3.connect(
            app.config['DATABASE'],
            detect_types=sqlite3.PARSE_DECLTYPES
        )
        g.db.row_factory = sqlite3.Row
    return g.db

        
@app.route('/registro', methods=['GET', 'POST'])
def registro():
    form = RegistrationForm()

    if form.validate_on_submit():
        username = form.username.data
        password = form.password.data

        db = get_db()
        cursor = db.cursor()
        
        try:
            # Verifica si el usuario ya existe
            cursor.execute("SELECT * FROM usuario WHERE username = ?", (username,))
            existing_user = cursor.fetchone()

            if existing_user:
                flash('¡Usuario ya registrado! Elija otro nombre de usuario.', 'danger')
            else:
                # Registra al nuevo usuario
                hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')
                cursor.execute("INSERT INTO usuario (username, password) VALUES (?, ?)", (username, hashed_password))
                db.commit()
                flash(f'¡Usuario {username} registrado con éxito!', 'success')
                return redirect(url_for('index'))
            
        finally:
            cursor.close()
            db.close()
    return render_template('registro.html', form=form)

@app.teardown_appcontext
def close_db(error):
    if hasattr(g, 'db'):
        g.db.close()

if __name__ == '__main__':
    app.run(debug=True)